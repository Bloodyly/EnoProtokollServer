package com.eno.protokolle.UI

class EditorActivity {
}