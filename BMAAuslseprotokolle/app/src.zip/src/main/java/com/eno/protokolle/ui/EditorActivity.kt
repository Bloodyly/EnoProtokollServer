package com.eno.protokolle.ui

class EditorActivity {
}