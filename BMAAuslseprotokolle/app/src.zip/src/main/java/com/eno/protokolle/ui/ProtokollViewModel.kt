// com/eno/protokolle/ui/ProtokollViewModel.kt
package com.eno.protokolle.ui

import androidx.lifecycle.ViewModel
import com.eno.protokolle.newmodel.ProtokollConstruct

class ProtokollViewModel : ViewModel() {
    var construct: ProtokollConstruct? = null
}
