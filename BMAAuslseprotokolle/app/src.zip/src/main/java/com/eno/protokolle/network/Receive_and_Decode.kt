package com.eno.protokolle.network

import android.content.Context
import android.util.Log
import com.eno.protokolle.newmodel.ProtokollCodec
import com.eno.protokolle.newmodel.ProtokollEnvelope
import com.eno.protokolle.prefs.AppPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ReceiveAndDecode {

    // Neuer Empfang für das *neue* Protokoll-JSON
    suspend fun receiveProtokollNew(
        context: Context,
        vertragsnummer: String,
        onLog: (String) -> Unit = {}   // ← NEU
    ): ProtokollEnvelope? = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext   // ← immer Application-Context verwenden

        try {
            onLog("→ Lade Einstellungen …")
            val prefs = AppPrefs.load(context)
            var failcount = 0
            val serverHost = prefs.host
            onLog("host: $serverHost")
            val port = prefs.port
            onLog("port: $port")
            var privateKey = prefs.aesB64
            if (privateKey.isBlank()) {privateKey="+FT7XNKeH9E7bg/WGWldaSkjMjdNMXbZH1c83PPkLbg="}
            val username = prefs.user
            onLog("user: $username")
            val password = prefs.pass
            onLog("pass: $password")

            // Validierung: falls settings fehlen
            if (privateKey.isBlank()
            ) {
                onLog("✗ Private KEY Fehlt")
                failcount++
            }
            if (serverHost.isBlank() || port !in 1..65535
            ) {
                onLog("✗ port unvollständig!")
                failcount++
            }
            if (username.isBlank() || password.isBlank()
            ) {
                onLog("✗ username/pass unvollständig!")
                failcount++
            }
            if (failcount > 0) {
                onLog("✗ Einstellungen laden fehlgeschlagen!")
                return@withContext null}
            // Mit Timeout verbinden
            onLog("→ Einstellungen geladen, $failcount Fehler. ")
            Socket().use { socket ->
                socket.connect(InetSocketAddress(serverHost, port), /* timeout ms */ 5000)
                DataOutputStream(socket.getOutputStream()).use { output ->
                    DataInputStream(socket.getInputStream()).use { input ->

                        // ✉️ Anfrage senden (username|password|vertragsnummer)
                        onLog("Sende Anfrage...")
                        val payload = "$username|$password|$vertragsnummer"
                        val encryptedRequest = NetworkHelper.encryptAES(payload, privateKey)
                        output.writeInt(encryptedRequest.size)
                        output.write(encryptedRequest)
                        output.flush()

                        // 📥 Antwort lesen (Length-Prefix)
                        onLog("Lese Antwort")
                        val length = input.readInt()
                        if (length <= 0 || length > 10 * 1024 * 1024) {
                            // einfacher Schutz gegen Unsinn
                            onLog("✗ Unerwartete Antwortlänge: $length")
                            Log.e("ReceiveNew", "Unerwartete Antwortlänge: $length")
                            return@withContext null
                        }
                        val encryptedResponse = ByteArray(length)
                        input.readFully(encryptedResponse)

                        // 🔓 Entschlüsseln (AES/ECB entsprechend deiner NetworkHelper-Implementierung)
                        onLog("Entschlüsseln...")
                        val decryptedJson = NetworkHelper.decryptAES(encryptedResponse, privateKey)

                        // 🧱 JSON decodieren
                        onLog("JSON-Decode...")
                        val env = ProtokollCodec.decode(decryptedJson)

                        // 💾 Optional: lokal cachen
                        onLog("Speichere Daten...")
                        ProtokollStorage.save(context, vertragsnummer, decryptedJson)

                        return@withContext env
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("ReceiveNew", "Fehler: ${e.message}", e)
            null
        }
    }
}
